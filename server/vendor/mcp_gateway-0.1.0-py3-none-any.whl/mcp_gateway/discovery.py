"""Per-backend discovery documents and their URL aliases.

Every URL listed in the spec returns the correct document for a registered backend;
an unknown name returns 404 on every path.
"""

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from mcp_gateway.backends import BackendTable, issuer_url, resource_url
from mcp_gateway.metadata import SCOPE, enable_public_client_metadata

# Force the patch so we can build metadata that matches.
enable_public_client_metadata()


def _authz_server_doc(base: str, name: str) -> dict:
    iss = issuer_url(base, name)
    return {
        "issuer": iss,
        "authorization_endpoint": f"{iss}/authorize",
        "token_endpoint": f"{iss}/token",
        "registration_endpoint": f"{iss}/register",
        "scopes_supported": [SCOPE],
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code", "refresh_token"],
        "token_endpoint_auth_methods_supported": ["none", "client_secret_post", "client_secret_basic"],
        "code_challenge_methods_supported": ["S256"],
    }


def _protected_resource_doc(base: str, name: str) -> dict:
    return {
        "resource": resource_url(base, name),
        "authorization_servers": [issuer_url(base, name)],
        "scopes_supported": [SCOPE],
    }


def _json(data: dict) -> JSONResponse:
    return JSONResponse(data, headers={"Cache-Control": "no-store"})


def _not_found(_request: Request) -> Response:
    return Response(status_code=404)


def build_discovery_routes(base: str, backends: BackendTable) -> list[Route]:
    """Return routes for all discovery URLs.

    Bare ``/.well-known/oauth-authorization-server`` and ``/.well-known/oauth-protected-resource``
    are 404 (ADR-0001: nothing is served at the bare root).
    """

    async def authz_server(request: Request) -> Response:
        name = request.path_params.get("name", "")
        if backends.get(name) is None:
            return Response(status_code=404)
        return _json(_authz_server_doc(base, name))

    async def protected_resource(request: Request) -> Response:
        name = request.path_params.get("name", "")
        if backends.get(name) is None:
            return Response(status_code=404)
        return _json(_protected_resource_doc(base, name))

    return [
        # Bare roots → 404
        Route("/.well-known/oauth-authorization-server", _not_found),
        Route("/.well-known/oauth-protected-resource", _not_found),
        # RFC 8414 path-appended forms
        Route("/.well-known/oauth-authorization-server/{name}", authz_server),
        Route("/.well-known/oauth-authorization-server/{name}/mcp", authz_server),
        Route("/.well-known/openid-configuration/{name}", authz_server),
        # RFC 9728 path-appended form
        Route("/.well-known/oauth-protected-resource/{name}/mcp", protected_resource),
        # Path-prefix aliases (client appends .well-known to the resource/issuer URL)
        Route("/{name}/.well-known/oauth-authorization-server", authz_server),
        Route("/{name}/.well-known/openid-configuration", authz_server),
        Route("/{name}/mcp/.well-known/oauth-authorization-server", authz_server),
        Route("/{name}/mcp/.well-known/openid-configuration", authz_server),
        Route("/{name}/mcp/.well-known/oauth-protected-resource", protected_resource),
    ]
