"""Registration client for internal gateway listener."""

import asyncio
import logging
from collections.abc import Awaitable, Callable, Mapping
from typing import Any

import httpx2

logger = logging.getLogger(__name__)


class RegistrationError(Exception):
    """Raised when registering a backend fails."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


async def register_once(
    client: httpx2.AsyncClient,
    internal_url: str,
    token: str,
    spec: Mapping[str, Any],
) -> None:
    """Register once with the internal listener at <internal_url>/backends."""
    url = f"{internal_url.rstrip('/')}/backends"
    headers = {"Authorization": f"Bearer {token}"}
    response = await client.post(url, json=dict(spec), headers=headers)
    if response.status_code != 200:
        raise RegistrationError(
            f"Registration failed with status {response.status_code}: {response.text}",
            status_code=response.status_code,
        )


async def register_forever(
    client: httpx2.AsyncClient,
    internal_url: str,
    token: str,
    spec: Mapping[str, Any],
    *,
    interval: int = 300,
    stop: asyncio.Event,
    sleep: Callable[[float], Awaitable[Any]] | None = None,
) -> None:
    """Continuously register with exponential backoff on failure and periodic re-registration."""
    backoff = 1
    max_backoff = 30

    while not stop.is_set():
        try:
            await register_once(client, internal_url, token, spec)
            backoff = 1
            sleep_time = interval
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            msg = f"{type(exc).__name__}: {exc}"
            if token and token in msg:
                msg = msg.replace(token, "[REDACTED]")
            upstream_token = spec.get("upstream_token")
            if isinstance(upstream_token, str) and upstream_token in msg:
                msg = msg.replace(upstream_token, "[REDACTED]")
            logger.warning("Registration failed: %s", msg)
            sleep_time = backoff
            backoff = min(backoff * 2, max_backoff)

        if stop.is_set():
            break

        if sleep is not None:
            await sleep(sleep_time)
        else:
            try:
                await asyncio.wait_for(stop.wait(), timeout=sleep_time)
            except TimeoutError:
                pass
