"""Bridge stdio MCP processes to Streamable HTTP at /mcp."""

import asyncio
import contextlib
import hmac
from collections.abc import AsyncIterator, Mapping, Sequence
from contextlib import asynccontextmanager
from typing import Any

import httpx2
from mcp.server.lowlevel import Server
from mcp.server.transport_security import TransportSecuritySettings
from starlette.applications import Starlette
from starlette.responses import Response
from starlette.routing import Route
from starlette.types import ASGIApp, Receive, Scope, Send

from mcp_gateway.proxy import Upstream
from mcp_gateway.registration import register_forever


class _BridgeBearerAuth:
    """Require Authorization: Bearer <token> for /mcp requests."""

    def __init__(self, app: ASGIApp, bearer_token: str) -> None:
        self.app = app
        self._token_bytes = bearer_token.encode("utf-8")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            path = scope.get("path", "")
            if path == "/mcp" or path.startswith("/mcp/"):
                auth_header = ""
                for k, v in scope.get("headers", []):
                    if k.lower() == b"authorization":
                        try:
                            auth_header = v.decode("latin-1")
                        except UnicodeDecodeError:
                            response = Response(status_code=401)
                            await response(scope, receive, send)
                            return
                        break

                if not auth_header.startswith("Bearer "):
                    response = Response(status_code=401)
                    await response(scope, receive, send)
                    return

                token = auth_header[7:].strip()
                try:
                    token_bytes = token.encode("utf-8")
                except UnicodeEncodeError:
                    response = Response(status_code=401)
                    await response(scope, receive, send)
                    return

                if not hmac.compare_digest(token_bytes, self._token_bytes):
                    response = Response(status_code=401)
                    await response(scope, receive, send)
                    return

        await self.app(scope, receive, send)


def build_app(
    command: str,
    args: Sequence[str],
    env: Mapping[str, str],
    *,
    name: str,
    bearer_token: str | None = None,
    extra_routes: Sequence[Route] = (),
    registration: tuple[httpx2.AsyncClient, str, str, Mapping[str, Any]] | None = None,
) -> Starlette:
    """Build a Starlette app serving one stdio child as Streamable HTTP at /mcp."""
    upstream = Upstream(command, args, env)
    server = Server(
        name,
        on_list_tools=upstream.list_tools,
        on_call_tool=upstream.call_tool,
    )

    app = server.streamable_http_app(
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
        custom_starlette_routes=list(extra_routes),
    )

    if bearer_token is not None:
        app.add_middleware(_BridgeBearerAuth, bearer_token=bearer_token)

    session_manager_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(a: Starlette) -> AsyncIterator[None]:
        reg_task: asyncio.Task[None] | None = None
        stop_event = asyncio.Event()

        if registration is not None:
            client, internal_url, token, spec = registration
            reg_task = asyncio.create_task(
                register_forever(client, internal_url, token, spec, stop=stop_event)
            )

        try:
            async with upstream.connect():
                server.instructions = upstream.instructions
                async with session_manager_lifespan(a):
                    yield
        finally:
            if reg_task is not None:
                stop_event.set()
                reg_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await reg_task

    app.router.lifespan_context = lifespan
    return app
