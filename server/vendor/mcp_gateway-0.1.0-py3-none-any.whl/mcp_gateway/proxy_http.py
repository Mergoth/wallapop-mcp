"""Streaming reverse proxy for MCP endpoints and public paths."""

import logging
from urllib.parse import quote, urlparse

import httpx2
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.types import Scope

from mcp_gateway.backends import Backend

logger = logging.getLogger(__name__)

_HOP_BY_HOP = frozenset({
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
})

_HOP_BY_HOP_RAW = frozenset({h.encode("latin-1") for h in _HOP_BY_HOP})


class PayloadTooLargeError(Exception):
    """Raised when the streamed request body exceeds the configured limit."""


def is_public_path_traversal(scope: Scope, name: str) -> bool:
    """Check if the part after /<name> contains traversal or unsafe sequences."""
    path = scope.get("path", "")
    prefix = f"/{name}"
    if path == prefix:
        path_after = ""
    elif path.startswith(f"/{name}/"):
        path_after = path[len(prefix):]
    else:
        path_after = path

    raw_path = scope.get("raw_path")
    if raw_path is None:
        raw_path = path.encode("latin-1", "replace")
    raw_prefix = prefix.encode("ascii")
    if raw_path == raw_prefix:
        raw_after = b""
    elif raw_path.startswith(raw_prefix + b"/"):
        raw_after = raw_path[len(raw_prefix):]
    else:
        raw_after = raw_path

    # Check for empty segment (//), backslash, NUL, or encoded slash (%2f/%2F)
    if "//" in path_after or b"//" in raw_after:
        return True
    if "\\" in path_after or b"\\" in raw_after:
        return True
    if "\x00" in path_after or b"\x00" in raw_after:
        return True
    if "%2f" in path_after.lower() or b"%2f" in raw_after.lower():
        return True

    # Check for . or .. segments (including %2e/%2E forms)
    for seg in path_after.split("/"):
        norm_seg = seg.lower().replace("%2e", ".")
        if norm_seg in (".", ".."):
            return True

    for raw_seg in raw_after.split(b"/"):
        norm_raw_seg = raw_seg.lower().replace(b"%2e", b".")
        if norm_raw_seg in (b".", b".."):
            return True

    return False


def _filter_request_headers(
    request: Request,
    backend: Backend,
    *,
    is_public: bool,
) -> list[tuple[str, str]]:
    filtered: list[tuple[str, str]] = []
    for k, v in request.headers.items():
        lower = k.lower()
        if lower in _HOP_BY_HOP or lower == "host":
            continue
        if lower == "authorization" or lower.startswith("x-gateway-"):
            continue
        filtered.append((k, v))

    parsed = urlparse(backend.url)
    filtered.append(("host", parsed.netloc))

    if not is_public and backend.upstream_token:
        filtered.append(("authorization", f"Bearer {backend.upstream_token}"))

    return filtered


def _build_target_url(
    backend: Backend,
    request: Request,
    *,
    is_public: bool,
    rest: str | None = None,
) -> str:
    if is_public:
        assert rest is not None
        parsed = urlparse(backend.url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        target = f"{origin}{quote(rest, safe='/')}"
    else:
        target = backend.url

    if request.url.query:
        sep = "&" if "?" in target else "?"
        target = f"{target}{sep}{request.url.query}"
    return target


async def forward_request(
    request: Request,
    backend: Backend,
    client: httpx2.AsyncClient,
    *,
    is_public: bool = False,
    rest: str | None = None,
    body_limit: int | None = None,
) -> Response:
    """Forward an HTTP request to the backend and stream the response back."""
    if is_public and body_limit is not None:
        cl_header = request.headers.get("content-length")
        if cl_header is not None:
            try:
                if int(cl_header) > body_limit:
                    return JSONResponse({"error": "payload_too_large"}, status_code=413)
            except ValueError:
                pass

    target_url = _build_target_url(backend, request, is_public=is_public, rest=rest)
    headers = _filter_request_headers(request, backend, is_public=is_public)

    content = None
    has_body = (
        "content-length" in request.headers
        or "transfer-encoding" in request.headers
        or request.method not in ("GET", "HEAD", "DELETE")
    )

    if has_body:
        async def body_stream():
            total = 0
            async for chunk in request.stream():
                if is_public and body_limit is not None:
                    total += len(chunk)
                    if total > body_limit:
                        raise PayloadTooLargeError()
                yield chunk

        content = body_stream()

    req = client.build_request(
        request.method,
        target_url,
        headers=headers,
        content=content,
        timeout=httpx2.Timeout(None, connect=5.0),
    )

    try:
        resp = await client.send(req, stream=True)
    except PayloadTooLargeError:
        return JSONResponse({"error": "payload_too_large"}, status_code=413)
    except (httpx2.TransportError, httpx2.TimeoutException) as exc:
        logger.warning("backend %s unreachable: %s", backend.name, type(exc).__name__)
        return JSONResponse(
            {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32000, "message": "backend unavailable"},
            },
            status_code=502,
        )

    async def response_stream():
        try:
            async for chunk in resp.aiter_raw():
                yield chunk
        except (httpx2.TransportError, httpx2.TimeoutException) as exc:
            logger.warning("backend %s stream error: %s", backend.name, type(exc).__name__)
        finally:
            await resp.aclose()

    streaming_resp = StreamingResponse(
        response_stream(),
        status_code=resp.status_code,
    )
    streaming_resp.raw_headers = [
        (k, v) for k, v in resp.headers.raw if k.lower() not in _HOP_BY_HOP_RAW
    ]
    return streaming_resp
