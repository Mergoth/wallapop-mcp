"""Gateway settings, read once from the environment."""

import ipaddress
import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path


class ConfigError(Exception):
    """The gateway refuses to start with this configuration."""


@dataclass(frozen=True)
class Settings:
    host: str
    port: int
    base_url: str
    google_client_id: str
    google_client_secret: str
    allowed_emails: frozenset[str]
    state_dir: Path
    registration_token: str
    internal_host: str = "127.0.0.1"
    internal_port: int = 8081
    public_body_limit: int = 26214400


def _is_loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _required(env: Mapping[str, str], name: str) -> str:
    value = env.get(name, "").strip()
    if not value:
        raise ConfigError(f"{name} is not set")
    return value


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    """Load settings from environment variables.

    ``GATEWAY_PUBLIC_URL`` is the base URL without trailing slash; required off loopback,
    defaults to ``http://<host>:<port>`` on loopback.
    """
    env = os.environ if env is None else env
    host = env.get("GATEWAY_HOST") or "127.0.0.1"
    raw_port = env.get("GATEWAY_PORT") or "8000"
    try:
        port = int(raw_port)
    except ValueError:
        raise ConfigError(f"GATEWAY_PORT={raw_port!r} is not an integer") from None

    base_url = env.get("GATEWAY_PUBLIC_URL", "").strip().rstrip("/")
    if not base_url:
        if not _is_loopback(host):
            raise ConfigError(
                f"GATEWAY_PUBLIC_URL is required when GATEWAY_HOST={host!r}"
            )
        base_url = f"http://{host}:{port}"

    raw_emails = _required(env, "GATEWAY_ALLOWED_EMAILS")
    emails: list[str] = []
    for entry in raw_emails.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if "@" not in entry:
            raise ConfigError(
                f"GATEWAY_ALLOWED_EMAILS: {entry!r} is not an email address"
            )
        emails.append(entry.lower())
    if not emails:
        raise ConfigError("GATEWAY_ALLOWED_EMAILS is not set")

    registration_token = _required(env, "GATEWAY_REGISTRATION_TOKEN")
    if len(registration_token) < 32:
        raise ConfigError(
            f"GATEWAY_REGISTRATION_TOKEN must be at least 32 characters (got {len(registration_token)})"
        )

    internal_host = env.get("GATEWAY_INTERNAL_HOST") or host

    raw_internal_port = env.get("GATEWAY_INTERNAL_PORT") or "8081"
    try:
        internal_port = int(raw_internal_port)
    except ValueError:
        raise ConfigError(f"GATEWAY_INTERNAL_PORT={raw_internal_port!r} is not an integer") from None

    raw_public_body_limit = env.get("GATEWAY_PUBLIC_BODY_LIMIT") or "26214400"
    try:
        public_body_limit = int(raw_public_body_limit)
    except ValueError:
        raise ConfigError(f"GATEWAY_PUBLIC_BODY_LIMIT={raw_public_body_limit!r} is not an integer") from None

    return Settings(
        host=host,
        port=port,
        base_url=base_url,
        google_client_id=_required(env, "GOOGLE_CLIENT_ID"),
        google_client_secret=_required(env, "GOOGLE_CLIENT_SECRET"),
        allowed_emails=frozenset(emails),
        state_dir=Path(_required(env, "GATEWAY_STATE_DIR")),
        registration_token=registration_token,
        internal_host=internal_host,
        internal_port=internal_port,
        public_body_limit=public_body_limit,
    )
