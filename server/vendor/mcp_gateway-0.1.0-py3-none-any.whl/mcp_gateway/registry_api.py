"""Internal Starlette application for backend registration."""

import hmac
import json
from urllib.parse import urlparse

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route
from starlette.types import ASGIApp, Receive, Scope, Send

from mcp_gateway.backends import (
    Backend,
    BackendTable,
    resource_url,
    validate_name,
    validate_public_paths,
)
from mcp_gateway.config import Settings


class _RegistrationAuthMiddleware:
    """Require a valid registration token on every route except GET /health."""

    def __init__(self, app: ASGIApp, token: str) -> None:
        self.app = app
        self._token_bytes = token.encode("utf-8")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            if scope["method"] == "GET" and scope["path"] == "/health":
                await self.app(scope, receive, send)
                return

            auth_header = ""
            for k, v in scope.get("headers", []):
                if k.lower() == b"authorization":
                    try:
                        auth_header = v.decode("latin-1")
                    except UnicodeDecodeError:
                        response = Response(status_code=401)
                        await response(scope, receive, send)
                        return
                    break

            if not auth_header.startswith("Bearer "):
                response = Response(status_code=401)
                await response(scope, receive, send)
                return

            token = auth_header[7:].strip()
            try:
                token_bytes = token.encode("utf-8")
            except UnicodeEncodeError:
                response = Response(status_code=401)
                await response(scope, receive, send)
                return

            if not hmac.compare_digest(token_bytes, self._token_bytes):
                response = Response(status_code=401)
                await response(scope, receive, send)
                return

        await self.app(scope, receive, send)


def build_internal_app(settings: Settings, backends: BackendTable) -> Starlette:
    """Build the internal Starlette app for backend registration and health checks."""
    base = settings.base_url.rstrip("/")

    async def health(request: Request) -> Response:
        return JSONResponse({"status": "ok"})

    async def list_backends(request: Request) -> Response:
        data = [
            {
                "name": b.name,
                "url": b.url,
                "title": b.title,
                "public_paths": list(b.public_paths),
            }
            for b in backends.all()
        ]
        return JSONResponse(data)

    async def register_backend(request: Request) -> Response:
        try:
            body = await request.json()
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JSONResponse({"error": "invalid json body"}, status_code=400)

        if not isinstance(body, dict):
            return JSONResponse({"error": "body must be an object"}, status_code=400)

        name = body.get("name")
        if not isinstance(name, str):
            return JSONResponse({"error": "name must be a string"}, status_code=400)
        try:
            validate_name(name)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

        url = body.get("url")
        if not isinstance(url, str):
            return JSONResponse({"error": "url must be a string"}, status_code=400)
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            return JSONResponse(
                {"error": "url must be http or https with a host"},
                status_code=400,
            )

        title = body.get("title")
        if title is None:
            title = name.capitalize()
        elif not isinstance(title, str):
            return JSONResponse({"error": "title must be a string"}, status_code=400)

        upstream_token = body.get("upstream_token")
        if upstream_token is not None and not isinstance(upstream_token, str):
            return JSONResponse({"error": "upstream_token must be a string"}, status_code=400)

        raw_public_paths = body.get("public_paths")
        public_paths: tuple[str, ...] = ()
        if raw_public_paths is not None:
            try:
                public_paths = validate_public_paths(raw_public_paths)
            except (ValueError, TypeError) as exc:
                return JSONResponse({"error": str(exc)}, status_code=400)

        backend = Backend(
            name=name,
            url=url,
            title=title,
            upstream_token=upstream_token,
            public_paths=public_paths,
        )
        backends.add(backend)

        res_url = resource_url(base, name)
        return JSONResponse({"name": name, "resource_url": res_url}, status_code=200)

    async def delete_backend(request: Request) -> Response:
        name = request.path_params["name"]
        backends.remove(name)
        return Response(status_code=204)

    routes = [
        Route("/health", health, methods=["GET"]),
        Route("/backends", list_backends, methods=["GET"]),
        Route("/backends", register_backend, methods=["POST"]),
        Route("/backends/{name:str}", delete_backend, methods=["DELETE"]),
    ]

    app = Starlette(routes=routes)
    app.add_middleware(_RegistrationAuthMiddleware, token=settings.registration_token)
    return app
