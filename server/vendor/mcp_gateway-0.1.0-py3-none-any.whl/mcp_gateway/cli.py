"""CLI entrypoint for mcp-gateway: serve, register, bridge."""

import argparse
import asyncio
import logging
import os
import signal
import sys
from collections.abc import Sequence

import httpx2
import uvicorn

from mcp_gateway.app import build_app as build_gateway_app
from mcp_gateway.backends import BackendTable
from mcp_gateway.bridge import build_app as build_bridge_app
from mcp_gateway.config import ConfigError, load_settings
from mcp_gateway.registration import register_forever
from mcp_gateway.registry_api import build_internal_app

logger = logging.getLogger(__name__)


class _CLIArgumentParser(argparse.ArgumentParser):
    """Argument parser that raises on error instead of calling sys.exit."""

    def error(self, message: str) -> None:
        sys.stderr.write(f"error: {message}\n")
        raise _CLIArgError(message)


class _CLIArgError(Exception):
    pass


async def _run_serve() -> None:
    settings = load_settings()
    backends = BackendTable(settings.state_dir / "backends.json")
    public_app = build_gateway_app(settings, backends=backends)
    internal_app = build_internal_app(settings, backends)

    public_config = uvicorn.Config(
        public_app,
        host=settings.host,
        port=settings.port,
        log_level="info",
    )
    internal_config = uvicorn.Config(
        internal_app,
        host=settings.internal_host,
        port=settings.internal_port,
        log_level="info",
    )

    public_server = uvicorn.Server(public_config)
    internal_server = uvicorn.Server(internal_config)

    await asyncio.gather(
        public_server.serve(),
        internal_server.serve(),
    )


def _cmd_serve(argv: Sequence[str]) -> int:
    try:
        asyncio.run(_run_serve())
    except ConfigError as exc:
        sys.stderr.write(f"mcp-gateway: {exc}\n")
        return 2
    return 0


async def _run_register(
    internal_url: str,
    token: str,
    spec: dict,
    interval: int,
) -> None:
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    try:
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)
    except (NotImplementedError, RuntimeError):
        pass

    async with httpx2.AsyncClient() as client:
        await register_forever(
            client,
            internal_url,
            token,
            spec,
            interval=interval,
            stop=stop,
        )


def _cmd_register(argv: Sequence[str]) -> int:
    parser = _CLIArgumentParser(prog="mcp-gateway register")
    parser.add_argument("--name", required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--title")
    parser.add_argument("--upstream-token-env")
    parser.add_argument("--public-path", action="append", default=[])
    parser.add_argument("--interval", type=int, default=300)

    try:
        args = parser.parse_args(list(argv))
    except _CLIArgError:
        return 2

    token = os.environ.get("GATEWAY_REGISTRATION_TOKEN", "").strip()
    if not token:
        sys.stderr.write("error: GATEWAY_REGISTRATION_TOKEN is required\n")
        return 2

    internal_url = os.environ.get("GATEWAY_INTERNAL_URL", "http://gateway:8081").strip()

    upstream_token = None
    if args.upstream_token_env:
        upstream_token = os.environ.get(args.upstream_token_env)

    spec: dict = {
        "name": args.name,
        "url": args.url,
    }
    if args.title:
        spec["title"] = args.title
    if upstream_token:
        spec["upstream_token"] = upstream_token
    if args.public_path:
        spec["public_paths"] = list(args.public_path)

    asyncio.run(_run_register(internal_url, token, spec, args.interval))
    return 0


async def _run_bridge(
    cmd: str,
    cmd_args: list[str],
    child_env: dict[str, str],
    name: str,
    host: str,
    port: int,
    bearer_token: str | None,
    registration: tuple[str, str, dict] | None,
) -> None:
    client: httpx2.AsyncClient | None = None
    reg = None
    if registration is not None:
        internal_url, reg_token, spec = registration
        client = httpx2.AsyncClient()
        reg = (client, internal_url, reg_token, spec)

    try:
        app = build_bridge_app(
            cmd,
            cmd_args,
            child_env,
            name=name,
            bearer_token=bearer_token,
            registration=reg,
        )
        config = uvicorn.Config(app, host=host, port=port, log_level="info")
        server = uvicorn.Server(config)
        await server.serve()
    finally:
        if client is not None:
            await client.aclose()


def _cmd_bridge(argv: Sequence[str]) -> int:
    argv_list = list(argv)
    if "--" not in argv_list:
        sys.stderr.write("error: child command after '--' is required\n")
        return 2

    sep_index = argv_list.index("--")
    bridge_opts = argv_list[:sep_index]
    child_cmd_parts = argv_list[sep_index + 1:]

    if not child_cmd_parts:
        sys.stderr.write("error: child command after '--' is required\n")
        return 2

    parser = _CLIArgumentParser(prog="mcp-gateway bridge")
    parser.add_argument("--name", required=True)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--title")
    parser.add_argument("--advertise-url")
    parser.add_argument("--upstream-token-env")
    parser.add_argument("--public-path", action="append", default=[])
    parser.add_argument("--pass-env-prefix", action="append", default=[])
    parser.add_argument("--no-register", action="store_true")

    try:
        args = parser.parse_args(bridge_opts)
    except _CLIArgError:
        return 2

    reg_token = os.environ.get("GATEWAY_REGISTRATION_TOKEN", "").strip()
    if not args.no_register and not reg_token:
        sys.stderr.write("error: GATEWAY_REGISTRATION_TOKEN is required unless --no-register is set\n")
        return 2

    internal_url = os.environ.get("GATEWAY_INTERNAL_URL", "http://gateway:8081").strip()
    advertise_url = args.advertise_url or f"http://{args.name}:{args.port}/mcp"

    upstream_token = None
    if args.upstream_token_env:
        upstream_token = os.environ.get(args.upstream_token_env)

    bearer_token = upstream_token

    child_env: dict[str, str] = {}
    for pfx in args.pass_env_prefix:
        for k, v in os.environ.items():
            if k.startswith(pfx):
                child_env[k] = v

    registration = None
    if not args.no_register:
        spec: dict = {
            "name": args.name,
            "url": advertise_url,
        }
        if args.title:
            spec["title"] = args.title
        if upstream_token:
            spec["upstream_token"] = upstream_token
        if args.public_path:
            spec["public_paths"] = list(args.public_path)

        registration = (internal_url, reg_token, spec)

    cmd = child_cmd_parts[0]
    cmd_args = child_cmd_parts[1:]

    asyncio.run(
        _run_bridge(
            cmd,
            cmd_args,
            child_env,
            name=args.name,
            host=args.host,
            port=args.port,
            bearer_token=bearer_token,
            registration=registration,
        )
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint: serve, register, or bridge."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        return _cmd_serve([])

    subcommand = argv[0]
    sub_args = argv[1:]

    if subcommand == "serve":
        return _cmd_serve(sub_args)
    elif subcommand == "register":
        return _cmd_register(sub_args)
    elif subcommand == "bridge":
        return _cmd_bridge(sub_args)
    elif subcommand in ("-h", "--help"):
        sys.stderr.write("Usage: mcp-gateway [serve|register|bridge] [options]\n")
        return 0
    else:
        sys.stderr.write(f"error: unknown subcommand {subcommand!r}\n")
        return 2
