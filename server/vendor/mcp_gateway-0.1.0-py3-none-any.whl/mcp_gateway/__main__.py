"""Entrypoint: delegate to mcp_gateway.cli.main."""

import sys

from mcp_gateway.cli import main

if __name__ == "__main__":
    sys.exit(main())
