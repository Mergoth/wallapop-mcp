"""Backend registry: name validation, URL helpers and persistent table."""

import json
import os
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mcp_gateway.config import ConfigError

_NAME_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}$")
_RESERVED = frozenset({"oauth", "health", "backends"})
_RESERVED_SEGMENTS = frozenset({"mcp", "authorize", "token", "register", "login", ".well-known"})


def validate_name(name: str) -> None:
    """Raise ``ValueError`` if *name* is not a valid backend identifier."""
    if not _NAME_RE.fullmatch(name):
        raise ValueError(
            f"backend name {name!r} must match {_NAME_RE.pattern}"
        )
    if name in _RESERVED:
        raise ValueError(f"backend name {name!r} is reserved")


def validate_public_paths(paths: Any) -> tuple[str, ...]:
    """Validate public_paths and return as a tuple of strings.

    Raise TypeError or ValueError if invalid.
    """
    if not isinstance(paths, list):
        raise TypeError("public_paths must be a list of strings")
    validated: list[str] = []
    for p in paths:
        if not isinstance(p, str):
            raise TypeError("public_paths elements must be strings")
        if not p.startswith("/"):
            raise ValueError(f"public path {p!r} must start with '/'")
        if "\\" in p:
            raise ValueError(f"public path {p!r} contains a backslash")
        if "%" in p:
            raise ValueError(f"public path {p!r} contains a percent character")
        if "//" in p:
            raise ValueError(f"public path {p!r} contains an empty segment")
        for seg in p.split("/"):
            if seg in (".", ".."):
                raise ValueError(f"public path {p!r} contains relative segment {seg!r}")
        segments = [s for s in p.strip("/").split("/") if s]
        if not segments:
            raise ValueError(f"public path {p!r} must have a first segment")
        first = segments[0]
        if first in _RESERVED_SEGMENTS:
            raise ValueError(f"public path {p!r} has reserved first segment {first!r}")
        validated.append(p)
    return tuple(validated)


def resource_url(base: str, name: str) -> str:
    return f"{base}/{name}/mcp"


def issuer_url(base: str, name: str) -> str:
    return f"{base}/{name}"


@dataclass(frozen=True)
class Backend:
    name: str
    url: str
    title: str
    upstream_token: str | None = None
    public_paths: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        validate_name(self.name)
        if not isinstance(self.public_paths, tuple):
            object.__setattr__(self, "public_paths", tuple(self.public_paths))


class BackendTable:
    """Backend registry with optional atomic persistence."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = Path(path) if path is not None else None
        self._backends: dict[str, Backend] = {}
        if self._path is not None and self._path.exists():
            self._load()

    def _load(self) -> None:
        assert self._path is not None
        try:
            raw = self._path.read_text(encoding="utf-8")
            data = json.loads(raw)
            if isinstance(data, dict):
                items = data.values()
            elif isinstance(data, list):
                items = data
            else:
                raise TypeError("root must be a list or dict")
            for item in items:
                if not isinstance(item, dict):
                    raise TypeError("items must be dicts")
                backend = Backend(
                    name=item["name"],
                    url=item["url"],
                    title=item["title"],
                    upstream_token=item.get("upstream_token"),
                    public_paths=tuple(item.get("public_paths", ())),
                )
                self._backends[backend.name] = backend
        except Exception as exc:
            raise ConfigError(f"Corrupt backend file {self._path}: {exc}") from exc

    def _save(self) -> None:
        if self._path is None:
            return
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_name(f"{self._path.name}.{uuid.uuid4().hex}.tmp")
        try:
            payload = [
                {
                    "name": b.name,
                    "url": b.url,
                    "title": b.title,
                    "upstream_token": b.upstream_token,
                    "public_paths": list(b.public_paths),
                }
                for b in self._backends.values()
            ]
            flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
            fd = os.open(tmp_path, flags, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._path)
            os.chmod(self._path, 0o600)
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise

    def add(self, backend: Backend) -> None:
        self._backends[backend.name] = backend
        self._save()

    def get(self, name: str) -> Backend | None:
        return self._backends.get(name)

    def remove(self, name: str) -> None:
        popped = self._backends.pop(name, None)
        if popped is not None:
            self._save()

    def names(self) -> frozenset[str]:
        return frozenset(self._backends)

    def all(self) -> list[Backend]:
        return list(self._backends.values())
