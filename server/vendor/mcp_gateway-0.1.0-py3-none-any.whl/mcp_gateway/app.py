"""Assemble the Starlette app: per-backend auth routes, Google sign-in and the /mcp stub."""

import base64
import logging
from urllib.parse import parse_qs, quote, unquote, urlencode

import httpx2
from mcp.server.auth.routes import create_auth_routes
from pydantic import AnyHttpUrl
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from mcp_gateway.backends import Backend, BackendTable, issuer_url, resource_url
from mcp_gateway.config import Settings
from mcp_gateway.discovery import build_discovery_routes
from mcp_gateway.metadata import (
    build_auth_settings,
    enable_public_client_metadata,
)
from mcp_gateway.oauth import (
    CALLBACK_PATH,
    BackendProvider,
    GoogleOAuthProvider,
)
from mcp_gateway.proxy_http import forward_request, is_public_path_traversal

logger = logging.getLogger(__name__)
_log = logging.getLogger("mcp_gateway.token")


def _parse_basic(header: str) -> tuple[str, str] | None:
    if not header.startswith("Basic "):
        return None
    try:
        decoded = base64.b64decode(header[6:], validate=True).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None
    if ":" not in decoded:
        return None
    client_id, secret = decoded.split(":", 1)
    return unquote(client_id), unquote(secret)


class _TokenClientAuthCompat:
    """Accept a client secret at /token in the form or as HTTP Basic, whichever the client sends.

    The SDK only accepts the method a client registered, and requires client_id in the form
    even for Basic. Clients we pre-register by hand (Gemini app/Enterprise) may use either.
    """

    def __init__(self, app: ASGIApp, provider: GoogleOAuthProvider) -> None:
        self.app = app
        self._provider = provider

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["method"] != "POST":
            await self.app(scope, receive, send)
            return
        # Match /<name>/token
        path = scope["path"]
        parts = path.strip("/").split("/")
        if len(parts) != 2 or parts[1] != "token":
            await self.app(scope, receive, send)
            return

        body = b""
        more = True
        while more:
            message = await receive()
            body += message.get("body", b"")
            more = message.get("more_body", False)

        headers = list(scope["headers"])
        form = parse_qs(body.decode("utf-8", "replace"), keep_blank_values=True)
        auth = next((v.decode("latin-1") for k, v in headers if k == b"authorization"), "")
        basic = _parse_basic(auth)
        client_id = (form.get("client_id") or [""])[0] or (basic[0] if basic else "")
        client = await self._provider.get_client(client_id) if client_id else None
        if client is not None:
            secret = basic[1] if basic else (form.get("client_secret") or [""])[0]
            form["client_id"] = [client_id]
            method = client.token_endpoint_auth_method
            if method == "client_secret_post" and secret:
                form["client_secret"] = [secret]
            elif method == "client_secret_basic" and secret and basic is None:
                creds = f"{quote(client_id, safe='')}:{quote(secret, safe='')}"
                headers.append((b"authorization", b"Basic " + base64.b64encode(creds.encode())))
            body = urlencode(form, doseq=True).encode()
            headers = [(k, v) for k, v in headers if k != b"content-length"]
            headers.append((b"content-length", str(len(body)).encode()))
            scope = {**scope, "headers": headers}

        replayed = False

        async def replay() -> Message:
            nonlocal replayed
            if not replayed:
                replayed = True
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        await self.app(scope, replay, send)


class _TokenRequestLog:
    """Log the shape of each /<name>/token call and the SDK's error body; never codes or secrets."""

    def __init__(self, app: ASGIApp, provider: GoogleOAuthProvider) -> None:
        self.app = app
        self._provider = provider

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["method"] != "POST":
            await self.app(scope, receive, send)
            return
        path = scope["path"]
        parts = path.strip("/").split("/")
        if len(parts) != 2 or parts[1] != "token":
            await self.app(scope, receive, send)
            return

        body_parts: list[bytes] = []
        more = True
        while more:
            message = await receive()
            body_parts.append(message.get("body", b""))
            more = message.get("more_body", False)
        body = b"".join(body_parts)

        form = parse_qs(body.decode("utf-8", "replace"))
        client_id = (form.get("client_id") or [""])[0]
        known = bool(client_id) and await self._provider.get_client(client_id) is not None
        req_headers = dict(scope["headers"])
        auth = req_headers.get(b"authorization", b"").decode("latin-1")

        replayed = False

        async def replay() -> Message:
            nonlocal replayed
            if not replayed:
                replayed = True
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        response_status = 0
        response_headers: list[tuple[bytes, bytes]] = []
        response_body = b""

        async def capture_send(message: Message) -> None:
            nonlocal response_status, response_headers, response_body
            if message["type"] == "http.response.start":
                response_status = message["status"]
                response_headers = list(message.get("headers", []))
            elif message["type"] == "http.response.body":
                response_body += message.get("body", b"")
            await send(message)

        await self.app(scope, replay, capture_send)
        content_type = req_headers.get(b"content-type", b"").decode("latin-1")
        _log.warning(
            "POST %s grant=%s client_id=%s known=%s form_keys=%s auth_header=%s "
            "content_type=%s -> %d %s",
            path,
            (form.get("grant_type") or [""])[0],
            client_id or "<missing>",
            known,
            sorted(form),
            auth.split(" ", 1)[0] if auth else "<none>",
            content_type,
            response_status,
            response_body[:300].decode("utf-8", "replace") if response_status >= 400 else "",
        )


def _www_authenticate(base: str, name: str) -> str:
    meta_url = f"{base}/.well-known/oauth-protected-resource/{name}/mcp"
    return f'Bearer error="invalid_token", resource_metadata="{meta_url}"'


def build_app(
    settings: Settings,
    *,
    backends: BackendTable | None = None,
    http_client: httpx2.AsyncClient | None = None,
    proxy_client: httpx2.AsyncClient | None = None,
) -> Starlette:
    enable_public_client_metadata()
    if backends is None:
        backends = BackendTable()

    if proxy_client is None:
        proxy_client = httpx2.AsyncClient(timeout=httpx2.Timeout(None, connect=5.0))

    provider = GoogleOAuthProvider(
        google_client_id=settings.google_client_id,
        google_client_secret=settings.google_client_secret,
        allowed_emails=settings.allowed_emails,
        base_url=settings.base_url,
        state_dir=settings.state_dir,
        http_client=http_client,
    )

    base = settings.base_url.rstrip("/")

    # Build per-backend sub-apps (cached by backend identity).
    _backend_cache: dict[str, tuple[Backend, ASGIApp]] = {}

    def _get_backend_sub_app(name: str) -> ASGIApp | None:
        backend = backends.get(name)
        if backend is None:
            _backend_cache.pop(name, None)
            return None
        cached = _backend_cache.get(name)
        if cached is not None and cached[0] == backend:
            return cached[1]

        view = BackendProvider(provider, name)
        iss = issuer_url(base, name)
        auth_settings = build_auth_settings(
            resource_url=resource_url(base, name),
            issuer_url=iss,
        )
        auth_routes = create_auth_routes(
            view,
            issuer_url=AnyHttpUrl(iss),
            client_registration_options=auth_settings.client_registration_options,
            revocation_options=None,
        )

        async def mcp_endpoint(request: Request) -> Response:
            b = backends.get(name)
            if b is None:
                return Response(status_code=404)
            auth_header = request.headers.get("authorization", "")
            token = (
                auth_header.removeprefix("Bearer ").strip()
                if auth_header.startswith("Bearer ")
                else ""
            )
            if not token:
                return Response(
                    status_code=401,
                    headers={"WWW-Authenticate": _www_authenticate(base, name)},
                )
            access = await provider.load_access_token(token, name)
            if access is None:
                return Response(
                    status_code=401,
                    headers={"WWW-Authenticate": _www_authenticate(base, name)},
                )
            return await forward_request(
                request,
                b,
                proxy_client,
                is_public=False,
            )

        async def login_endpoint(request: Request) -> Response:
            b = backends.get(name)
            if b is None:
                return Response(status_code=404)
            return await provider.login(request, name, b.title)

        sub_routes = [
            Route(
                "/mcp",
                mcp_endpoint,
                methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
            ),
            Route("/login", login_endpoint, methods=["GET", "POST"]),
            *auth_routes,
        ]
        sub_app = Starlette(routes=sub_routes)
        _backend_cache[name] = (backend, sub_app)
        return sub_app

    async def backend_dispatch(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await Response(status_code=404)(scope, receive, send)
            return
        path = scope["path"]
        parts = path.strip("/").split("/", 1)
        name = parts[0]
        backend = backends.get(name) if name else None
        if backend is None:
            await Response(status_code=404)(scope, receive, send)
            return
        rest = "/" + parts[1] if len(parts) > 1 else "/"

        if any(rest.startswith(p) for p in backend.public_paths):
            if is_public_path_traversal(scope, name):
                await Response(status_code=404)(scope, receive, send)
                return
            req = Request(scope, receive)
            resp = await forward_request(
                req,
                backend,
                proxy_client,
                is_public=True,
                rest=rest,
                body_limit=settings.public_body_limit,
            )
            await resp(scope, receive, send)
            return

        sub_app = _get_backend_sub_app(name)
        if sub_app is None:
            await Response(status_code=404)(scope, receive, send)
            return
        child_scope = dict(scope)
        child_scope["path"] = rest
        await sub_app(child_scope, receive, send)

    # ---- Google callback (shared) ----

    async def google_callback(request: Request) -> Response:
        return await provider.google_callback(request)

    routes: list[Route] = []
    routes.extend(build_discovery_routes(base, backends))
    routes.append(Route(CALLBACK_PATH, google_callback, methods=["GET"]))

    app = Starlette(routes=routes)
    app.router.default = backend_dispatch
    app.state.provider = provider  # type: ignore[union-attr]
    app.add_middleware(_TokenClientAuthCompat, provider=provider)
    app.add_middleware(_TokenRequestLog, provider=provider)
    return app
